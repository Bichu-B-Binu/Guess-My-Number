let secretNumber=Math.floor(Math.random()*20+1);
console.log(secretNumber);
let score=20;
let highscore=0;
document.querySelector('.score').textContent=score;
document.querySelector('.highscore').textContent=highscore;

document.querySelector('.check').addEventListener('click',
function(){
const gusse=Number(document.querySelector(".guess").value);
const displayMessage=(message)=>{
document.querySelector('.message').textContent=message;
}
if(!gusse)  {
            // document.querySelector('.message').textContent="⛔Not A Number";
            displayMessage("⛔Not A Number")
            }
else if(gusse===secretNumber)  {
                                // document.querySelector('.message').textContent="🎊Corect Number";
                                displayMessage("🎊Corect Number")
                                document.querySelector('body').style.backgroundColor = '#60b347';
                                document.querySelector('.number').style.width = '30rem';
                                document.querySelector('.number').textContent=secretNumber;
                                if (score>highscore){
                                                    highscore=score;
                                                    document.querySelector('.highscore').textContent=highscore;
                                                    }

                                }
else if(gusse!==secretNumber)  {
    
                                    if(score>1){
                                                // document.querySelector('.message').textContent=gusse>secretNumber?"📈Too High":"📉Too Low";
                                                displayMessage(gusse>secretNumber?"📈Too High":"📉Too Low")
                                                score--;
                                                document.querySelector('.score').textContent=score;
                                               
                                                 }
                                    else{
                                        // document.querySelector('.message').textContent="😒Lost the game";
                                        displayMessage("😒Lost the game")
                                        document.querySelector('.score').textContent=0;
                                        }
                                }
else{
        //  document.querySelector('.message').textContent="❌ Invalid Iteam";
        displayMessage("❌ Invalid Iteam")
    }
}
)
// else if(gusse>secretNumber){
    
//     if(score>1){
//         document.querySelector('.message').textContent="📈Too High";
//         score--;
//         document.querySelector('.score').textContent=score;
//         document.querySelector('.highscore').textContent=score;
// }
//     else{
//     document.querySelector('.message').textContent="😒Lost the game";
//     document.querySelector('.score').textContent=0;
//     }
// }
// else if(gusse<secretNumber){
    
//     if(score>1){
//         document.querySelector('.message').textContent="📉Too Low";
//         score--;
//         document.querySelector('.score').textContent=score;
//         document.querySelector('.highscore').textContent=score;

// }
//     else{
//     document.querySelector('.message').textContent="😒Lost the game";
//     document.querySelector('.score').textContent=0;
//     }

// }
// else{
//     document.querySelector('.message').textContent="❌ Invalid Iteam";

// }
// }
// )
document.querySelector('.again').addEventListener('click',
function(){
            const secretNumbers=Math.floor(Math.random()*20+1);
            const scores=20;
            document.querySelector('body').style.backgroundColor='#222';
            document.querySelector('.number').style.width="15rem";
            document.querySelector('.message').textContent="Start guessing...";
            score=scores;
            document.querySelector('.score').textContent=score;
            document.querySelector('.guess').value="";
            secretNumber=secretNumbers;  
            document.querySelector('.number').textContent="?"  
           

 
          }
)